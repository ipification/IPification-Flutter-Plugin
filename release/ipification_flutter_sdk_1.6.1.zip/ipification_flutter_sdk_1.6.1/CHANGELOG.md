## 1.3

Initial Release

## 1.4

Bug Fixed: Redirect_uri

## 1.5

Synced with native library 1.5

## 1.5.1

Exposed functions : setState , addQueryParam

## 1.6

Synced with native library 1.6

## 1.6.1

Synced with native library 1.6.1
Supported more information from response
