//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<ipification_plugin/IPificationPlugin.h>)
#import <ipification_plugin/IPificationPlugin.h>
#else
@import ipification_plugin;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [IPificationPlugin registerWithRegistrar:[registry registrarForPlugin:@"IPificationPlugin"]];
}

@end
