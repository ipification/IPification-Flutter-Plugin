## 1.3

Initial Release

## 1.4

Bug Fixed: Redirect_uri

## 1.5

Sync with native library 1.5

## 1.5.1

Exposed functions : setState , addQueryParam

## 1.6

Sync with native library 1.6

## 1.6.1

Sync with native library 1.6.1

## 1.6.2

Sync with native library 1.6.2

## 1.6.3

Sync with native library 1.6.3


## 1.7

Sync with native library 1.7


## 1.7.1

Support Null-Safety


## 1.8.1

Sync with native library 1.8.1


## 1.8.2

Fix header issue